package com.example.networkcontrol

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : AppCompatActivity() {
    
    private lateinit var rootStatusText: TextView
    private lateinit var selfNetworkSwitch: Switch
    private lateinit var otherAppsLayout: LinearLayout
    private var hasRoot = false
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        // 初始化UI组件
        rootStatusText = findViewById(R.id.rootStatusText)
        selfNetworkSwitch = findViewById(R.id.selfNetworkSwitch)
        otherAppsLayout = findViewById(R.id.otherAppsLayout)
        
        // 检测Root权限
        checkRootPermission()
        
        // 设置本App网络控制开关
        setupSelfNetworkControl()
        
        // 如果有Root权限，显示其他App控制选项
        if (hasRoot) {
            setupOtherAppsControl()
        } else {
            // 非Root模式，隐藏其他App控制
            otherAppsLayout.visibility = android.view.View.GONE
            Toast.makeText(this, "当前为标准模式，仅可控制本App网络", Toast.LENGTH_LONG).show()
        }
    }
    
    /**
     * 检测设备是否具有Root权限
     */
    private fun checkRootPermission() {
        hasRoot = RootUtils.isDeviceRooted()
        
        if (hasRoot) {
            rootStatusText.text = "当前模式：Root模式（完整功能）"
            rootStatusText.setTextColor(getColor(android.R.color.holo_green_dark))
        } else {
            rootStatusText.text = "当前模式：标准模式（仅控制本App）"
            rootStatusText.setTextColor(getColor(android.R.color.holo_orange_dark))
        }
    }
    
    /**
     * 设置本App的网络控制
     */
    private fun setupSelfNetworkControl() {
        // 检查当前网络状态
        val isNetworkEnabled = NetworkController.isNetworkEnabled(this)
        selfNetworkSwitch.isChecked = isNetworkEnabled
        
        selfNetworkSwitch.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                // 启用网络
                NetworkController.enableNetwork(this)
                Toast.makeText(this, "已启用网络连接", Toast.LENGTH_SHORT).show()
            } else {
                // 禁用网络
                NetworkController.disableNetwork(this)
                Toast.makeText(this, "已禁用网络连接", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    /**
     * 设置其他App的网络控制（仅Root模式）
     */
    private fun setupOtherAppsControl() {
        val appListView = ListView(this)
        val installedApps = PackageUtils.getInstalledApps(this)
        
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, installedApps)
        appListView.adapter = adapter
        
        appListView.setOnItemClickListener { _, _, position, _ ->
            val selectedApp = installedApps[position]
            // 这里可以打开一个对话框来控制选中App的网络
            showAppNetworkControlDialog(selectedApp)
        }
        
        otherAppsLayout.addView(appListView)
    }
    
    /**
     * 显示App网络控制对话框
     */
    private fun showAppNetworkControlDialog(appName: String) {
        val builder = android.app.AlertDialog.Builder(this)
        builder.setTitle("控制 $appName 的网络")
        
        val options = arrayOf("启用网络", "禁用网络")
        builder.setItems(options) { _, which ->
            when (which) {
                0 -> {
                    // 启用网络
                    val uid = PackageUtils.getAppUid(this, appName)
                    if (uid != -1) {
                        RootUtils.executeCommand("iptables -D OUTPUT -m owner --uid-owner $uid -j DROP")
                        Toast.makeText(this, "已启用 $appName 的网络", Toast.LENGTH_SHORT).show()
                    }
                }
                1 -> {
                    // 禁用网络
                    val uid = PackageUtils.getAppUid(this, appName)
                    if (uid != -1) {
                        RootUtils.executeCommand("iptables -A OUTPUT -m owner --uid-owner $uid -j DROP")
                        Toast.makeText(this, "已禁用 $appName 的网络", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
        builder.show()
    }
}
