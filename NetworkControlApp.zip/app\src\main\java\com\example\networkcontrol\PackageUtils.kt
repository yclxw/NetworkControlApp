package com.example.networkcontrol

import android.content.Context
import android.content.pm.PackageManager

/**
 * 包管理工具类
 * 用于获取已安装应用信息
 */
object PackageUtils {
    
    /**
     * 获取所有已安装的应用列表
     * @return 应用名称列表
     */
    fun getInstalledApps(context: Context): List<String> {
        val packageManager = context.packageManager
        val packages = packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
        
        val appList = mutableListOf<String>()
        for (packageInfo in packages) {
            // 只显示用户安装的应用，排除系统应用
            if ((packageInfo.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) == 0) {
                val appName = packageManager.getApplicationLabel(packageInfo).toString()
                appList.add(appName)
            }
        }
        
        return appList.sorted()
    }
    
    /**
     * 根据应用名称获取UID
     * @param appName 应用名称
     * @return 应用UID，如果未找到返回-1
     */
    fun getAppUid(context: Context, appName: String): Int {
        val packageManager = context.packageManager
        val packages = packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
        
        for (packageInfo in packages) {
            val currentAppName = packageManager.getApplicationLabel(packageInfo).toString()
            if (currentAppName == appName) {
                return packageInfo.uid
            }
        }
        
        return -1
    }
}
