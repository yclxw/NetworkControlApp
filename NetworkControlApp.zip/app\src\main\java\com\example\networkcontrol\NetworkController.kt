package com.example.networkcontrol

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build

/**
 * 网络控制器
 * 支持Root模式和非Root模式
 */
object NetworkController {
    
    /**
     * 检查网络是否启用
     */
    fun isNetworkEnabled(context: Context): Boolean {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val network = connectivityManager.activeNetwork
            val capabilities = connectivityManager.getNetworkCapabilities(network)
            return capabilities != null && (
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ||
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
            )
        } else {
            @Suppress("DEPRECATION")
            val networkInfo = connectivityManager.activeNetworkInfo
            return networkInfo != null && networkInfo.isConnected
        }
    }
    
    /**
     * 启用网络连接（非Root模式）
     * 注意：Android系统不允许应用直接启用/禁用系统网络，这里仅能控制本App的网络行为
     */
    fun enableNetwork(context: Context) {
        if (RootUtils.isDeviceRooted()) {
            // Root模式：移除iptables规则
            val uid = context.applicationInfo.uid
            RootUtils.executeCommand("iptables -D OUTPUT -m owner --uid-owner $uid -j DROP")
        } else {
            // 非Root模式：使用ConnectivityManager恢复网络连接
            val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                // Android 5.0+ 可以使用setProcessDefaultNetwork来恢复网络
                connectivityManager.bindProcessToNetwork(null)
            }
        }
    }
    
    /**
     * 禁用网络连接（非Root模式）
     */
    fun disableNetwork(context: Context) {
        if (RootUtils.isDeviceRooted()) {
            // Root模式：添加iptables规则阻止网络访问
            val uid = context.applicationInfo.uid
            RootUtils.executeCommand("iptables -A OUTPUT -m owner --uid-owner $uid -j DROP")
        } else {
            // 非Root模式：限制本App的网络访问
            val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                // Android 5.0+ 可以解绑网络，但不会完全禁用
                // 这是一种有限的控制方式
                connectivityManager.bindProcessToNetwork(null)
            }
            
            // 提示用户这是有限制的控制
            android.widget.Toast.makeText(
                context,
                "标准模式下只能有限控制网络，建议获取Root权限以获得完整功能",
                android.widget.Toast.LENGTH_LONG
            ).show()
        }
    }
}
