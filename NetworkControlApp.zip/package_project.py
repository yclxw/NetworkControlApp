import zipfile
import os

def zip_directory(path, zip_path):
    """将目录打包为ZIP文件"""
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(path):
            for file in files:
                # 跳过某些不需要的文件
                if file.endswith('.py') or file == 'package_project.py':
                    continue
                    
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, path)
                zipf.write(file_path, arcname)
                print(f"添加: {arcname}")

if __name__ == "__main__":
    project_dir = os.path.dirname(os.path.abspath(__file__))
    zip_path = os.path.join(project_dir, '..', 'NetworkControlApp.zip')
    
    print(f"正在打包项目...")
    print(f"项目目录: {project_dir}")
    print(f"输出文件: {zip_path}")
    
    zip_directory(project_dir, zip_path)
    
    print(f"\n打包完成！")
    print(f"ZIP文件大小: {os.path.getsize(zip_path) / 1024 / 1024:.2f} MB")
    print(f"文件位置: {zip_path}")
