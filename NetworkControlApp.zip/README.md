# 网络控制助手 - Android应用

## 项目说明

这是一个Android网络控制应用，支持通过Root权限或非Root方式控制App的网络连接。

## 功能特性

### Root模式（完整功能）
- 使用iptables防火墙规则控制网络
- 可以控制本App和其他任意App的网络连接
- 完整的网络禁用/启用功能

### 标准模式（非Root）
- 使用Android系统API
- 仅能控制本App的网络连接
- 功能受限但无需Root权限

## 编译说明

### 方法一：使用Android Studio（推荐）

1. 下载并安装 [Android Studio](https://developer.android.com/studio)
2. 打开Android Studio，选择 "Open an existing project"
3. 选择本项目文件夹 `NetworkControlApp`
4. 等待Gradle同步完成
5. 点击菜单 `Build` → `Build Bundle(s) / APK(s)` → `Build APK`
6. 编译完成后，APK文件位于 `app/build/outputs/apk/debug/app-debug.apk`

### 方法二：使用命令行编译

```bash
# 进入项目目录
cd NetworkControlApp

# Windows
gradlew.bat assembleDebug

# macOS/Linux
./gradlew assembleDebug
```

编译后的APK位于：`app/build/outputs/apk/debug/app-debug.apk`

### 方法三：在线编译服务

如果不想安装Android Studio，可以使用以下在线编译服务：

1. **Appetize.io** - 上传代码进行云端编译
2. **Codemagic** - CI/CD平台，支持Android编译
3. **Bitrise** - 移动应用CI/CD平台

## 项目结构

```
NetworkControlApp/
├── app/
│   ├── src/main/
│   │   ├── java/com/example/networkcontrol/
│   │   │   ├── MainActivity.kt          # 主活动
│   │   │   ├── RootUtils.kt             # Root权限工具
│   │   │   ├── NetworkController.kt     # 网络控制器
│   │   │   └── PackageUtils.kt          # 包管理工具
│   │   ├── res/
│   │   │   ├── layout/
│   │   │   │   └── activity_main.xml    # 主界面布局
│   │   │   └── values/
│   │   │       ├── strings.xml          # 字符串资源
│   │   │       ├── colors.xml           # 颜色资源
│   │   │       └── themes.xml           # 主题资源
│   │   └── AndroidManifest.xml          # 应用清单
│   └── build.gradle                      # App模块构建配置
├── build.gradle                          # 顶层构建配置
├── settings.gradle                       # 项目设置
└── gradle.properties                     # Gradle属性
```

## 使用说明

1. 安装APK到Android设备
2. 首次启动时，应用会自动检测Root权限
3. 如果有Root权限，会显示"Root模式"，可以使用全部功能
4. 如果没有Root权限，会显示"标准模式"，只能控制本App网络
5. 使用开关按钮控制网络连接

## 注意事项

- Root模式需要设备已获取Root权限
- 标准模式下功能受限，这是Android系统的安全限制
- 部分Android版本可能对网络控制有更严格的限制
- 建议在测试设备上先验证功能

## 技术实现

- **语言**: Kotlin
- **最低SDK**: Android 7.0 (API 24)
- **目标SDK**: Android 13 (API 33)
- **依赖**: AndroidX, Material Design

## 许可证

本项目仅供学习和个人使用。
