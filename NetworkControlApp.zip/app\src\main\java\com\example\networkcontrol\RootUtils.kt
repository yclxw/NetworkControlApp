package com.example.networkcontrol

import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * Root权限工具类
 * 用于检测和执行Root命令
 */
object RootUtils {
    
    /**
     * 检测设备是否已Root
     */
    fun isDeviceRooted(): Boolean {
        return checkRootMethod1() || checkRootMethod2() || checkRootMethod3()
    }
    
    /**
     * 方法1：检查SU二进制文件是否存在
     */
    private fun checkRootMethod1(): Boolean {
        val buildTags = android.os.Build.TAGS
        return buildTags != null && buildTags.contains("test-keys")
    }
    
    /**
     * 方法2：检查常见Root路径
     */
    private fun checkRootMethod2(): Boolean {
        val paths = arrayOf(
            "/system/app/Superuser.apk",
            "/sbin/su",
            "/system/bin/su",
            "/system/xbin/su",
            "/data/local/xbin/su",
            "/data/local/bin/su",
            "/system/sd/xbin/su",
            "/system/bin/failsafe/su",
            "/data/local/su"
        )
        for (path in paths) {
            if (java.io.File(path).exists()) {
                return true
            }
        }
        return false
    }
    
    /**
     * 方法3：尝试执行su命令
     */
    private fun checkRootMethod3(): Boolean {
        var process: Process? = null
        return try {
            process = Runtime.getRuntime().exec(arrayOf("/system/xbin/which", "su"))
            val bufferedReader = BufferedReader(InputStreamReader(process.inputStream))
            bufferedReader.readLine() != null
        } catch (t: Throwable) {
            false
        } finally {
            process?.destroy()
        }
    }
    
    /**
     * 执行Root命令
     * @param command 要执行的命令
     * @return 命令执行结果
     */
    fun executeCommand(command: String): String {
        var process: Process? = null
        var outputStream: java.io.DataOutputStream? = null
        var result = ""
        
        try {
            process = Runtime.getRuntime().exec("su")
            outputStream = java.io.DataOutputStream(process.outputStream)
            outputStream.writeBytes("$command\n")
            outputStream.writeBytes("exit\n")
            outputStream.flush()
            
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                result += line + "\n"
            }
            
            process.waitFor()
        } catch (e: Exception) {
            result = "Error: ${e.message}"
        } finally {
            try {
                outputStream?.close()
            } catch (e: Exception) {
                e.printStackTrace()
            }
            process?.destroy()
        }
        
        return result
    }
}
