package com.example.blockredfruit

import android.content.Context
import android.content.pm.PackageManager

/**
 * 扫描设备上所有名称包含"红果"的应用，返回其包名列表。
 */
object AppScanner {

    /** 应用名称匹配关键词 */
    const val KEYWORD = "红果"

    /**
     * 获取所有名称包含 [KEYWORD] 的已安装应用的包名。
     * 排除自身（BlockRedFruit），避免误伤。
     */
    fun getTargetApps(context: Context): List<String> {
        val pm = context.packageManager
        val selfPkg = context.packageName

        return try {
            pm.getInstalledApplications(PackageManager.GET_META_DATA)
                .filter { app ->
                    val label = pm.getApplicationLabel(app).toString()
                    label.contains(KEYWORD, ignoreCase = false) && app.packageName != selfPkg
                }
                .map { it.packageName }
                .distinct()
        } catch (e: Exception) {
            emptyList()
        }
    }

    /**
     * 获取目标应用的名称和包名（用于 UI 展示）。
     */
    fun getTargetAppDetails(context: Context): List<AppInfo> {
        val pm = context.packageManager
        val selfPkg = context.packageName

        return try {
            pm.getInstalledApplications(PackageManager.GET_META_DATA)
                .filter { app ->
                    val label = pm.getApplicationLabel(app).toString()
                    label.contains(KEYWORD, ignoreCase = false) && app.packageName != selfPkg
                }
                .map { app ->
                    AppInfo(
                        label = pm.getApplicationLabel(app).toString(),
                        packageName = app.packageName
                    )
                }
                .sortedBy { it.label }
        } catch (e: Exception) {
            emptyList()
        }
    }

    data class AppInfo(
        val label: String,
        val packageName: String
    )
}
