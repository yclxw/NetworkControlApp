# BlockRedFruit ProGuard rules

# Keep VPN Service
-keep class com.example.blockredfruit.BlockVpnService { *; }

# Keep AppScanner model
-keep class com.example.blockredfruit.AppScanner$AppInfo { *; }
