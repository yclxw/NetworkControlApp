package com.example.blockredfruit

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.blockredfruit.databinding.ItemAppInfoBinding

class AppListAdapter : ListAdapter<AppScanner.AppInfo, AppListAdapter.ViewHolder>(DiffCallback) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemAppInfoBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class ViewHolder(private val binding: ItemAppInfoBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(app: AppScanner.AppInfo) {
            binding.textAppName.text = app.label
            binding.textPackageName.text = app.packageName
        }
    }

    companion object DiffCallback : DiffUtil.ItemCallback<AppScanner.AppInfo>() {
        override fun areItemsTheSame(old: AppScanner.AppInfo, new: AppScanner.AppInfo) =
            old.packageName == new.packageName

        override fun areContentsTheSame(old: AppScanner.AppInfo, new: AppScanner.AppInfo) =
            old == new
    }
}
