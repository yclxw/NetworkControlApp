package com.example.blockredfruit

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.blockredfruit.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "BlockRedFruit"
    }

    private lateinit var binding: ActivityMainBinding
    private lateinit var appAdapter: AppListAdapter

    private val vpnPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            try {
                if (result.resultCode == RESULT_OK) {
                    startVpnService()
                } else {
                    binding.switchVpn.isChecked = false
                    Toast.makeText(this, R.string.vpn_permission_denied, Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Log.e(TAG, "vpnPermission error", e)
                binding.switchVpn.isChecked = false
            }
        }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
            try {
                requestVpnPermission()
            } catch (e: Exception) {
                Log.e(TAG, "notificationPermission error", e)
                binding.switchVpn.isChecked = false
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            binding = ActivityMainBinding.inflate(layoutInflater)
            setContentView(binding.root)
            setupRecyclerView()
            setupSwitch()
        } catch (e: Exception) {
            Log.e(TAG, "onCreate error", e)
            Toast.makeText(this, "Init error: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        try {
            refreshAppList()
        } catch (e: Exception) {
            Log.e(TAG, "onResume error", e)
        }
    }

    private fun setupRecyclerView() {
        appAdapter = AppListAdapter()
        binding.recyclerTargetApps.layoutManager = LinearLayoutManager(this)
        binding.recyclerTargetApps.adapter = appAdapter
    }

    private fun setupSwitch() {
        binding.switchVpn.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                handleStart()
            } else {
                stopVpnService()
            }
        }
    }

    private fun handleStart() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            when {
                ContextCompat.checkSelfPermission(
                    this, Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED -> requestVpnPermission()
                else -> notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        } else {
            requestVpnPermission()
        }
    }

    private fun requestVpnPermission() {
        try {
            val intent = VpnService.prepare(this)
            if (intent != null) {
                vpnPermissionLauncher.launch(intent)
            } else {
                startVpnService()
            }
        } catch (e: Exception) {
            Log.e(TAG, "requestVpnPermission error", e)
            binding.switchVpn.isChecked = false
            Toast.makeText(this, "VPN error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startVpnService() {
        try {
            val intent = Intent(this, BlockVpnService::class.java).apply {
                action = BlockVpnService.ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
            Toast.makeText(this, R.string.vpn_started, Toast.LENGTH_SHORT).show()
            refreshAppList()
        } catch (e: Exception) {
            Log.e(TAG, "startVpnService error", e)
            binding.switchVpn.isChecked = false
            Toast.makeText(this, "Start failed: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun stopVpnService() {
        try {
            val intent = Intent(this, BlockVpnService::class.java).apply {
                action = BlockVpnService.ACTION_STOP
            }
            startService(intent)
            Toast.makeText(this, R.string.vpn_stopped, Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Log.e(TAG, "stopVpnService error", e)
        }
    }

    private fun refreshAppList() {
        try {
            val apps = AppScanner.getTargetAppDetails(this)
            appAdapter.submitList(apps)
            binding.textEmpty.text = if (apps.isEmpty()) {
                getString(R.string.no_target_apps)
            } else {
                getString(R.string.target_count, apps.size)
            }
        } catch (e: Exception) {
            Log.e(TAG, "refreshAppList error", e)
            binding.textEmpty.text = "Scan error"
        }
    }
}
