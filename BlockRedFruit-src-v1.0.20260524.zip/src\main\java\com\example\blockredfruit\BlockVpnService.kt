package com.example.blockredfruit

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import java.io.FileInputStream
import java.io.IOException

class BlockVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.example.blockredfruit.START"
        const val ACTION_STOP = "com.example.blockredfruit.STOP"
        const val ACTION_REFRESH = "com.example.blockredfruit.REFRESH"

        private const val NOTIFICATION_ID = 1001
        private const val CHANNEL_ID = "block_red_fruit_vpn"
        private const val TAG = "BlockRedFruit"
    }

    private var vpnInterface: ParcelFileDescriptor? = null
    private var readerThread: Thread? = null
    private var packageReceiver: BroadcastReceiver? = null

    override fun onCreate() {
        super.onCreate()
        try {
            createNotificationChannel()
            registerPackageReceiver()
        } catch (e: Exception) {
            Log.e(TAG, "onCreate error", e)
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            when (intent?.action) {
                ACTION_START -> startVpn()
                ACTION_STOP -> stopVpn()
                ACTION_REFRESH -> refreshVpn()
            }
        } catch (e: Exception) {
            Log.e(TAG, "onStartCommand error", e)
            stopVpn()
        }
        return START_STICKY
    }

    private fun startVpn() {
        if (vpnInterface != null) return

        val targetApps = AppScanner.getTargetApps(this)

        if (targetApps.isEmpty()) {
            Log.w(TAG, "No target apps")
            stopSelf()
            return
        }

        Log.i(TAG, "Starting VPN for: $targetApps")

        startForeground(NOTIFICATION_ID, buildNotification(targetApps.size))

        val builder = Builder()
            .setSession(getString(R.string.app_name))
            .addAddress("10.8.0.2", 24)
            .addRoute("0.0.0.0", 0)
            .setMtu(1500)
            .setBlocking(true)

        for (pkg in targetApps) {
            try {
                builder.addAllowedApplication(pkg)
            } catch (e: Exception) {
                Log.w(TAG, "Cannot add $pkg", e)
            }
        }

        try {
            builder.addDisallowedApplication(packageName)
        } catch (e: Exception) {
            Log.w(TAG, "Cannot exclude self", e)
        }

        try {
            vpnInterface = builder.establish()
            if (vpnInterface == null) {
                Log.e(TAG, "establish returned null")
                stopVpn()
                return
            }
            Log.i(TAG, "VPN established")
            startReader()
        } catch (e: Exception) {
            Log.e(TAG, "establish failed", e)
            stopVpn()
        }
    }

    private fun stopVpn() {
        Log.i(TAG, "Stopping VPN")
        readerThread?.interrupt()
        readerThread = null
        try { vpnInterface?.close() } catch (_: Exception) {}
        vpnInterface = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun refreshVpn() {
        val currentTargets = AppScanner.getTargetApps(this)
        if (currentTargets.isEmpty()) {
            stopVpn()
            return
        }
        stopVpnKeepService()
        startVpn()
    }

    private fun stopVpnKeepService() {
        readerThread?.interrupt()
        readerThread = null
        try { vpnInterface?.close() } catch (_: Exception) {}
        vpnInterface = null
    }

    override fun onDestroy() {
        unregisterPackageReceiver()
        stopVpnKeepService()
        super.onDestroy()
    }

    private fun startReader() {
        readerThread = Thread({
            val buffer = ByteArray(32767)
            try {
                val input = FileInputStream(vpnInterface!!.fileDescriptor)
                while (!Thread.currentThread().isInterrupted) {
                    val len = input.read(buffer)
                    if (len < 0) break
                }
            } catch (_: IOException) {
                Log.d(TAG, "Reader closed")
            } catch (_: InterruptedException) {
                Log.d(TAG, "Reader interrupted")
            }
        }, "VpnReader").apply { isDaemon = true; start() }
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.notification_channel_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply { description = getString(R.string.notification_channel_desc) }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(targetCount: Int) =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.off_icon)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text, targetCount))
            .setOngoing(true)
            .setContentIntent(
                PendingIntent.getActivity(
                    this, 0, Intent(this, MainActivity::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            )
            .build()

    private fun registerPackageReceiver() {
        packageReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                val pkg = intent?.data?.schemeSpecificPart ?: return
                val label = try {
                    packageManager.getApplicationLabel(
                        packageManager.getApplicationInfo(pkg, 0)
                    ).toString()
                } catch (_: Exception) { return }
                if (label.contains(AppScanner.KEYWORD, ignoreCase = false)) {
                    Log.i(TAG, "Package changed: $pkg")
                    refreshVpn()
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(packageReceiver, filter, Context.RECEIVER_EXPORTED)
            } else {
                registerReceiver(packageReceiver, filter)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Cannot register receiver", e)
        }
    }

    private fun unregisterPackageReceiver() {
        packageReceiver?.let { try { unregisterReceiver(it) } catch (_: Exception) {} }
        packageReceiver = null
    }
}
